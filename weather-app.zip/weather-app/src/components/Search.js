import React, { useState } from 'react';

const Search = ({ setCity }) => {
    const [inputCity, setInputCity] = useState('');  // Local state for city input

    // Function to handle search button click
    const handleSearch = () => {
        setCity(inputCity);  // Update the city state in App.js
    };

    return (
        <div>
            <input
                type="text"
                placeholder="Enter city"
                value={inputCity}
                onChange={(e) => setInputCity(e.target.value)}  // Update local input state as user types
            />
            <button onClick={handleSearch}>Search</button>  {/* Call handleSearch on button click */}
        </div>
    );
};

export default Search;
