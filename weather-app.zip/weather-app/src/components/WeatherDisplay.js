const WeatherDisplay = ({ data }) => {
    if (!data) return <p>Loading...</p>;  // Show loading text if data is not available

    const { name, main, weather } = data;

    // Extract the icon code from the weather data
    const iconCode = weather[0].icon;

    // Construct the URL for the weather icon
    const iconUrl = `http://openweathermap.org/img/wn/10d@2x.png`;

    return (
        <div className="weather-display">
            <h2>{name}</h2>
            {/* Display the weather icon */}
            <img src={iconUrl} alt={weather[0].description} />
            <p>{weather[0].description}</p>  {/* Display weather condition (e.g., clear sky) */}
            <p>Temperature: {main.temp}°C</p>  {/* Display current temperature */}
        </div>
    );
};

export default WeatherDisplay;

