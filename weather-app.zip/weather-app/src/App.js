import React, { useState, useEffect } from 'react';
import Search from './components/Search';  // Import Search component
import WeatherDisplay from './components/WeatherDisplay';  // Import WeatherDisplay component
import './App.css';
import axios from 'axios';  // Don't forget to import axios for making the API request

const App = () => {
    const [city, setCity] = useState('');  // State for the city name
    const [weatherData, setWeatherData] = useState(null);  // State to hold weather data

    // useEffect will run when the 'city' state changes
    useEffect(() => {
        if (!city) return;  // Don't fetch if no city is provided

        const API_KEY = '19aa5f6f112104d8eccbac033d948903';  // Replace with your actual API key
        const URL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;

        const fetchData = async () => {
            try {
                const response = await axios.get(URL);
                setWeatherData(response.data);  // Set the fetched weather data
            } catch (error) {
                console.error('Error fetching weather data:', error);
                alert('City not found or API error.');
            }
        };

        fetchData();  // Fetch data whenever 'city' changes

    }, [city]);  // Dependency array: Effect will run only when the city changes

    return (
        <div className="App">
            <h1>Weather App</h1>
            <Search setCity={setCity} />  {/* Pass setCity function to Search component */}
            {weatherData && <WeatherDisplay data={weatherData} />}  {/* Pass weather data to WeatherDisplay */}
        </div>
    );
};

export default App;
